class Chicken extends MovableObject {

    y = 90;
    height = 60;
    width = 60;


    constructor() {
        super().loadImage('../img/3_enemies_chicken/chicken_normal/1_walk/1_w.png');
        this.x = 100 + Math.random() * 150;
        // this.y = 90;
        // this.height = 60;
        // this.width = 60;
    }
}