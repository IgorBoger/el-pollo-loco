class MovableObject {
    x = 10;
    y = 50;
    height = 100;
    width = 60;
    img;


    loadImage(path) {
        this.img = new Image();
        this.img.src = path;
    }


    moveLeft() {
        // this.x -= 10;
        console.log('Moving left to', this.x);
    }


    moveRight() {
        // this.x += 10;
        console.log('Moving right to', this.x);
    }
}