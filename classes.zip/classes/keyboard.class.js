class KeyBaord {
    // left = true;
    // right = false;
    // space = false;

    LEFT = false;
    RIGHT = false;
    UP = false;
    SPACE = false;
    DOWN = false;

    // LEFT;
    // RIGHT;
    // UP;
    // SPACE;
    // DOWN;


    constructor() {

    }


}