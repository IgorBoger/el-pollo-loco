class KeyBaord {
    LEFT = false;
    RIGHT = false;
    UP = false;
    SPACE = false;
    DOWN = false;


    constructor() {

    }


}