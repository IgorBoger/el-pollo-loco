class Cloud extends MovableObject {
    height = 80;
    width = 200;
    y = 0;


    constructor() {
        super().loadImage('../img/5_background/layers/4_clouds/1.png');

        this.x = Math.random() * 50;
        // this.height = 80;
        // this.width = 200;
        // this.y = 0;
    }
}