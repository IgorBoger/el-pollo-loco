class Character extends MovableObject {
    // leftArrowKey = 37;
    // rightArrowKey = 39;


    constructor() {
        super().loadImage('../img/2_character_pepe/2_walk/W-21.png');
    }


    jump() {

    }
}