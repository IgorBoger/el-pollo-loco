class StartScreen extends OverlayScreen {

    startScreenConfig = {
        overlayId: 'winOverlay',
        imageSrc: 'img/You won, you lost/You Win A.png',
        // overlayAlpha: 0.18,
        // overlayColor: '#ff8c00',
        // fadeSpeed: 0.06
    };

    constructor(ctx, canvas) {
        super(ctx, canvas);
        this.init(this.startScreenConfig);
    }
}