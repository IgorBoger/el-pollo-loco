function seedI18n() {
  const batch = db.batch();
  seedLang(batch, 'DE');
  seedLang(batch, 'ES');
  seedLang(batch, 'EN');
  commitSeed(batch);
}

function seedLang(batch, lang) {
  const ref = getI18nDocRef(lang);
  const data = getSeedData(lang);
  batch.set(ref, data, { merge: true });
}

function getI18nDocRef(lang) {
  return db.collection('i18n').doc(lang);
}

function getSeedData(lang) {
  return I18N[lang] || {};
}

function commitSeed(batch) {
  batch.commit()
    .then(() => console.log('I18N seed done ✅'))
    .catch(e => console.error('I18N seed failed ❌', e));
}

// HTML 
// <script src="./js/i18n-seed.js"></script>